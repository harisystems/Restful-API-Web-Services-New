<?php 

//$server = "server name / ip";

$server = "localhost";

$username = "root";

$password = "";

$db = "phpapi_demo";



$con = mysqli_connect($server,$username,$password,$db);

?>